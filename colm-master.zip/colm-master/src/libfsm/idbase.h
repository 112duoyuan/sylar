#ifndef _IDBASE_H
#define _IDBASE_H

void translatedHostData( ostream &out, const std::string &data );

#endif

