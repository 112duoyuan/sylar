#ifndef __UTIL_H
#define __UTIL_H

void handleAlarm( int );
void processArgs( int argc, char** argv );
void expandTab( char *dst, const char *src );

#endif

