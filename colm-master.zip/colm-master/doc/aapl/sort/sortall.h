/** 
 * \defgroup sort Sort
 * \brief Sorting routines.
 */

#include "insertsort.h"
#include "mergesort.h"
#include "bubblesort.h"
#include "quicksort.h"
